package Assignment2;

import java.util.Stack;

public class Assignment02 {

	public static void main(String[] args) {

		String[] equation = { "(1+2)*4-3" };
		if (equation.length != 1) {
			System.out.println("Unable to convert to postfix, Please check your expression.");
			System.exit(1);
		}
		try {
			System.out.println("Expression: "+equation[0]);
			processor(equation);
		} catch (Exception e) {
			System.out.println("Incorrect expression: " + equation[0]);
		}
	}

	public static void processor(String[] equation) {
		String expression = insertBlanks(equation[0]);
		String[] elements = expression.split(" ");
		result(elements);
	}
	
	public static void result(String[] elements) {
		Stack<Character> operator = new Stack<>();
		Stack<Character> resultstack = new Stack<>();
		for (String element : elements) {
			if (element.length() == 0)
				continue;
			else if (element.charAt(0) == '+' || element.charAt(0) == '-') {
				while (!operator.isEmpty() && (
						operator.peek() == '+' || operator.peek() == '-'|| 
						operator.peek() == '*' || operator.peek() == '/'|| 
						operator.peek() == '%' || operator.peek() == '^')) {
					resultstack.push(operator.pop());
				}
				operator.push(element.charAt(0));
			} else if (element.charAt(0) == '*' || element.charAt(0) == '/' || element.charAt(0) == '%') {
				while (!operator.isEmpty() && (
						operator.peek() == '*' || operator.peek() == '/'|| 
						operator.peek() == '%' || operator.peek() == '^')) {
					resultstack.push(operator.pop());
				}
				operator.push(element.charAt(0));
			} else if (element.charAt(0) == '^') {
				while (!operator.isEmpty() && (operator.peek() == '^')) {
					resultstack.push(operator.pop());
				}
				operator.push(element.charAt(0));
			} else if (element.charAt(0) == '(') {
				operator.push('(');
			} else if (element.charAt(0) == ')') {
				while (operator.peek() != '(') {
					resultstack.push(operator.pop());
				}
				operator.pop();
			} else {
				resultstack.push(element.charAt(0));
			}
		}

		while (!operator.isEmpty()) {
			char oper = operator.pop();
			resultstack.push(oper);
		}
		
		System.out.println("----- After Conversion into Postfix Expression -----");
		System.out.print("Expression: ");
		for (Character element : resultstack) {
			System.out.print(element + " ");
		}
	}

	public static String insertBlanks(String s) {
		String expression = "";
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == '(' || s.charAt(i) == ')' || 
				s.charAt(i) == '+' || s.charAt(i) == '-' || 
				s.charAt(i) == '*' || s.charAt(i) == '/' || 
				s.charAt(i) == '%' || s.charAt(i) == '^') {
				expression = expression + " " + s.charAt(i) + " ";
			}else {
				expression += s.charAt(i);
			}
		}
		return expression;
	}
}