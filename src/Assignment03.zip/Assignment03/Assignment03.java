package Assignment03;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class Assignment03 {
	public static void processor(String content) {
		Map<Integer, Integer> products = new LinkedHashMap<>();
		Map<Integer, Integer> customers = new LinkedHashMap<>();
		String [] customer = content.split(","); // splits the string with comma

		int [] productsId = new int[customer.length];
		int [] productsQuantity = new int[customer.length];
		int [] customerId = new int[customer.length];
		int [] productPrice = new int[customer.length];
		for (int i = 0;i<customer.length;i++) {
			String [] details = customer[i].split(" ");
			for(int j = 0; j<details.length; j++) {
				customerId[i] = Integer.parseInt(details[0]);
				productsId[i] = Integer.parseInt(details[3]);
				productPrice[i] = Integer.parseInt(details[5]);
				productsQuantity[i] = Integer.parseInt(details[6]);
			}
		}

		for(int i = 0;i<productsId.length; i++) {
			if (products.containsKey(productsId[i])) {
			    products.put(productsId[i],(products.get(productsId[i])+productsQuantity[i]));
			} else { 
				products.put(productsId[i],productsQuantity[i]);
			}
			if(customers.containsKey(customerId[i])) {
				customers.put(customerId[i],(customers.get(customerId[i])+(productPrice[i] * productsQuantity[i])));
			}else {
				customers.put(customerId[i], (productPrice[i] * productsQuantity[i]));
			}
		}
		print(products,customers);
	}

	public static void print(Map<Integer, Integer> products, Map<Integer, Integer> customers ) {
		System.out.println("######## General Store ########");
		System.out.println("---------------------------------");
		System.out.println("***** Products List *****");
		System.out.println("Product's Id\tQuantity");
		for (Map.Entry<Integer, Integer> me :products.entrySet()) {
			System.out.print(me.getKey() + "\t\t");
			System.out.println(me.getValue());
			}
		System.out.println();
		System.out.println("***** Customer's Bill List *****");
		System.out.println("Customer's Id\tTotal Bill");
		for (Map.Entry<Integer, Integer> me :customers.entrySet()) {
		    System.out.print(me.getKey() + "\t\t");
		    System.out.println(me.getValue()); 
		}
	}

	public static void reader() throws IOException{
		BufferedReader fileReader = null;
		try {
			fileReader = new BufferedReader(new FileReader("Sales.txt"));
			String str, content = "";
			while ((str = fileReader.readLine()) != null) {
				content = content + str +",";
			}
			processor(content);
		}
		catch (Exception ex){
			System.out.println("Unable to read the file.");
		}
		finally {
			if (fileReader != null) {
				fileReader.close();
			}
		}
	}
	
	public static void main(String[] args) throws IOException {
		reader();
	}

}

